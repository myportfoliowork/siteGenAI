require('dotenv').config();
const express = require('express'), path = require('path'), fs = require('fs');
const rateLimit = require('express-rate-limit');
const Anthropic = require('@anthropic-ai/sdk');

const app = express();
app.use(express.json({ limit: '6mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5';
const ai = process.env.ANTHROPIC_API_KEY ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY }) : null;
const limiter = rateLimit({ windowMs: 60000, max: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many requests, slow down' } });

/* ---------- storage: MongoDB if MONGODB_URI is set, otherwise a JSON file ---------- */
let store;
if (process.env.MONGODB_URI) {
  const mongoose = require('mongoose');
  mongoose.connect(process.env.MONGODB_URI).then(() => console.log('MongoDB connected')).catch(e => console.error('MongoDB error:', e.message));
  const Site = mongoose.model('Site', new mongoose.Schema(
    { _id: String, owner: String, name: String, spec: String, ledger: String, score: Number, updated: Number }, { versionKey: false }));
  store = {
    kind: 'mongodb',
    put: (id, d) => Site.findByIdAndUpdate(id, { $set: { ...d, updated: Date.now() } }, { upsert: true, new: true }).lean(),
    get: id => Site.findById(id).lean(),
    list: owner => Site.find({ owner }).sort({ updated: -1 }).limit(50).lean()
  };
} else {
  const f = path.join(__dirname, 'data', 'sites.json');
  fs.mkdirSync(path.dirname(f), { recursive: true });
  const load = () => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return {}; } };
  store = {
    kind: 'file',
    put: async (id, d) => { const a = load(); a[id] = { ...d, _id: id, updated: Date.now() }; fs.writeFileSync(f, JSON.stringify(a)); return a[id]; },
    get: async id => load()[id] || null,
    list: async owner => Object.values(load()).filter(s => s.owner === owner).sort((a, b) => b.updated - a.updated)
  };
}

const uid = r => String(r.get('x-user') || 'anon').slice(0, 40);
const okId = id => /^[a-z0-9]{4,24}$/i.test(id);
const parseJSON = t => JSON.parse(t.slice(t.indexOf('{'), t.lastIndexOf('}') + 1));

app.get('/api/health', (q, s) => s.json({ ai: provider !== 'none', provider, model: provider === 'gemini' ? GMODEL : MODEL, db: store.kind, github: !!process.env.GITHUB_TOKEN }));

/* ---------- AI: keys never leave the server. Free option: Google Gemini. Paid option: Claude. ---------- */
const GKEY = process.env.GEMINI_API_KEY, GMODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const provider = GKEY ? 'gemini' : ai ? 'claude' : 'none';
const SYS = 'You are a JSON API. Reply with a single valid JSON object only. No prose, no markdown.';
async function generate(m) {
  const msgs = m.map(x => ({ role: x.role === 'assistant' ? 'assistant' : 'user', content: String(x.content).slice(0, 60000) }));
  if (provider === 'gemini') {
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GMODEL}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GKEY },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYS }] },
        contents: msgs.map(x => ({ role: x.role === 'assistant' ? 'model' : 'user', parts: [{ text: x.content }] })),
        generationConfig: { responseMimeType: 'application/json', maxOutputTokens: 8192, temperature: 0.8 }
      })
    });
    const j = await r.json();
    if (!r.ok) throw new Error((j.error && j.error.message) || 'Gemini HTTP ' + r.status);
    return ((j.candidates && j.candidates[0] && j.candidates[0].content.parts) || []).map(p => p.text || '').join('');
  }
  const r = await ai.messages.create({ model: MODEL, max_tokens: 8000, system: SYS, messages: msgs });
  return r.content.filter(b => b.type === 'text').map(b => b.text).join('');
}
app.post('/api/ai', limiter, async (req, res) => {
  if (provider === 'none') return res.status(503).json({ error: 'No AI key set. Add GEMINI_API_KEY (free) or ANTHROPIC_API_KEY to .env' });
  const m = req.body.messages;
  if (!Array.isArray(m) || !m.length) return res.status(400).json({ error: 'messages required' });
  try { res.json({ json: parseJSON(await generate(m)) }); }
  catch (e) { console.error(e.message); res.status(502).json({ error: 'AI request failed: ' + e.message }); }
});

/* ---------- projects ---------- */
app.get('/api/sites', async (q, s) => s.json(await store.list(uid(q))));
app.get('/api/sites/:id', async (q, s) => {
  if (!okId(q.params.id)) return s.status(400).json({ error: 'bad id' });
  const d = await store.get(q.params.id);
  d ? s.json(d) : s.status(404).json({ error: 'not found' });
});
app.put('/api/sites/:id', async (q, s) => {
  const id = q.params.id;
  if (!okId(id)) return s.status(400).json({ error: 'bad id' });
  const old = await store.get(id);
  if (old && old.owner && old.owner !== uid(q)) return s.status(403).json({ error: 'not your project' });
  const { name, spec, ledger, score } = q.body;
  s.json(await store.put(id, { owner: uid(q), name: String(name || '').slice(0, 100), spec: String(spec || ''), ledger: String(ledger || ''), score: +score || 0 }));
});

/* ---------- one-click GitHub Pages deploy ---------- */
app.post('/api/deploy', limiter, async (req, res) => {
  const T = process.env.GITHUB_TOKEN;
  if (!T) return res.status(503).json({ error: 'GITHUB_TOKEN is not set on the server' });
  const { repo, html } = req.body;
  if (!/^[a-z0-9][a-z0-9-]{0,60}$/.test(repo || '') || typeof html !== 'string' || !html) return res.status(400).json({ error: 'valid repo name and html required' });
  const gh = (p, o = {}) => fetch('https://api.github.com' + p, { ...o, headers: { Authorization: `Bearer ${T}`, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'Content-Type': 'application/json', 'User-Agent': 'sitegen-ai' } });
  try {
    const me = await (await gh('/user')).json();
    if (!me.login) return res.status(401).json({ error: 'GitHub token is invalid' });
    const c = await gh('/user/repos', { method: 'POST', body: JSON.stringify({ name: repo, auto_init: true, description: 'Generated by SiteGen AI' }) });
    if (!c.ok && c.status !== 422) return res.status(502).json({ error: 'Could not create repository: ' + (await c.text()) });
    const info = await (await gh(`/repos/${me.login}/${repo}`)).json();
    const branch = info.default_branch || 'main';
    const ex = await gh(`/repos/${me.login}/${repo}/contents/index.html?ref=${branch}`);
    const sha = ex.ok ? (await ex.json()).sha : undefined;
    const put = await gh(`/repos/${me.login}/${repo}/contents/index.html`, { method: 'PUT', body: JSON.stringify({ message: 'Deploy site generated by SiteGen AI', content: Buffer.from(html).toString('base64'), sha, branch }) });
    if (!put.ok) return res.status(502).json({ error: 'Could not upload site: ' + (await put.text()) });
    await gh(`/repos/${me.login}/${repo}/pages`, { method: 'POST', body: JSON.stringify({ source: { branch, path: '/' } }) }); // 409 means Pages is already on
    res.json({ url: `https://${me.login}.github.io/${repo}/`, repoUrl: `https://github.com/${me.login}/${repo}` });
  } catch (e) { console.error(e.message); res.status(502).json({ error: 'Deploy failed: ' + e.message }); }
});

app.listen(process.env.PORT || 3000, () => console.log(`SiteGen AI running on http://localhost:${process.env.PORT || 3000}  (db: ${store.kind}, ai: ${provider})`));
