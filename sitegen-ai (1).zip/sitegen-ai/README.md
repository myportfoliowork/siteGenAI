# SiteGen AI

Describe a website, and SiteGen AI builds it, audits its own claims (TruthTrace), asks permission for risky edits (Permission Guardian), tests it with simulated visitors (Audience Lab) and deploys it to GitHub Pages in one click.

**Stack:** Node.js + Express, Anthropic Claude API, MongoDB (or a local JSON file), GitHub REST API. The frontend is a single file in `public/index.html`.

## 1. Run it locally
```bash
npm install
cp .env.example .env      # on Windows: copy .env.example .env
# fill in .env (see below), then:
npm start                 # open http://localhost:3000
```
The header shows a status pill: `AI on · DB mongodb · GitHub on`. Anything shown as OFF is not configured yet.

## 2. Get your keys
| Variable | Where to get it |
|---|---|
| `GEMINI_API_KEY` (free) | https://aistudio.google.com > Get API key. No credit card. Free tier is rate limited, and Google may use free-tier requests to improve its products. If `gemini-2.5-flash` is rejected, copy a current model name from AI Studio into `GEMINI_MODEL`. |
| `ANTHROPIC_API_KEY` (optional, paid) | https://console.anthropic.com > Settings > API keys (add credits under Billing) |
| `MONGODB_URI` | MongoDB Atlas free cluster > Connect > Drivers. Replace `<password>`, and allow your IP (or 0.0.0.0/0 for a demo) under Network Access. Leave empty to use a local file instead. |
| `GITHUB_TOKEN` | GitHub > Settings > Developer settings > Personal access tokens (classic) > scope **repo** |

Never commit `.env`. It is already in `.gitignore`.

## 3. Put the project on GitHub
```bash
git init && git add -A && git commit -m "SiteGen AI"
gh repo create sitegen-ai --public --source=. --push
```

## 4. Host it online (Render, free tier)
1. Render.com > New > Web Service > connect the GitHub repo (`render.yaml` is included).
2. Add the three environment variables from `.env`.
3. Deploy. You get a public URL such as `https://sitegen-ai.onrender.com`.

## How the features map to the code
- `POST /api/ai` calls Claude. The key stays on the server and requests are rate limited (20 per minute per IP).
- `PUT/GET /api/sites/:id` saves and shares projects in MongoDB (or `data/sites.json`).
- `POST /api/deploy` creates a GitHub repo, uploads `index.html` and enables GitHub Pages.
- MVP score, Guardian risk rules and change receipts run in the browser (`public/index.html`).

## Before the demo
- A live demo URL on Render sleeps when idle on the free tier. Open it a minute before you present.
- Anyone with your public URL can use your API key through the app. Set a spending limit in the Anthropic console.
- Keep a screen recording as a backup.
